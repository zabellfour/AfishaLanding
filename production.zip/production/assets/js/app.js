(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

(function ($) {
    'use strict';

    // When DOM is ready

    $(function () {
        var wow = new WOW({
            boxClass: 'wow',
            animateClass: 'animated',
            mobile: false,
            live: true,
            scrollContainer: null
        });
        wow.init();
        //mob Nav
        function mobNav(opener, close) {
            var $opener = $(opener);
            var $close = $(close);
            var $body = $('body');
            $opener.on('click', function () {
                $body.toggleClass('nav-active');
            });
            $close.on('click', function () {
                $body.toggleClass('nav-active');
            });
        }
        mobNav('.menu-opener', '.menu-close');

        var scroll = new SmoothScroll('[data-scroll]');

        $(".bottom-slider").owlCarousel({

            items: 1,

            nav: true,
            dots: true,
            loop: true,
            center: true
        });
        $(".events-slider").owlCarousel({
            margin: 130,
            items: 1,
            stagePadding: 480,
            nav: true,
            dots: false,
            loop: true,
            center: true,
            responsive: {
                0: {
                    items: 1,
                    stagePadding: 40,
                    margin: 10,
                    mouseDrag: false,
                    touchDrag: true
                },
                480: {
                    items: 1,
                    stagePadding: 100,
                    margin: 25,
                    mouseDrag: false,
                    touchDrag: true
                },
                768: {
                    items: 1,
                    stagePadding: 140,
                    margin: 30,
                    mouseDrag: false,
                    touchDrag: true
                },
                1024: {
                    stagePadding: 240,
                    margin: 40
                },
                1370: {
                    stagePadding: 370,
                    margin: 120
                },
                1500: {
                    margin: 130,
                    stagePadding: 400
                }
            }
        });
    });
})(jQuery);

},{}]},{},[1]);
